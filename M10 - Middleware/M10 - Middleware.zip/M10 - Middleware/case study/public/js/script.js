function sendName() {
    let username = document.getElementById("username").value
    document.getElementById("login").href = username
}